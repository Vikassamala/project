import logo from './logo.svg';
import './App.css';
import Blogs from './components/blogs/Blogs'
import NvBar from './components/headers'
import AddBlog from './components/blogs/AddBlog';
import {signIn,signout} from './components/Authentication';
import {Link,Route, BrowserRouter,Switch  } from "react-router-dom";
import {useState} from 'react';
import {Provider} from 'react-redux';
import {createStore} from 'redux';
import {reducer} from "./reducer";

function App() {

  const store=createStore(reducer);
/*const[user,setUser]=useState();
const [loginInfo,setInfo] =useState(0);
  const signInBtnClick=async()=>
  {
    let usr =await signIn();
    setUser({user:usr});
    console.log(user)
  }

  
  const signOutBtnClick =  () => 
  {
    let usr=signout();
    console.log("before logout")
    console.log(user)
    setInfo({loginInfo:!loginInfo});
  console.log("after logout")
  console.log(user)
    
  };*/
  return (
   <Provider store={store}>
   <NvBar/>
   </Provider>
   );
}

export default App;
