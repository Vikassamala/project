import React, { Component } from 'react';
import {Link,Route, BrowserRouter,Switch  } from "react-router-dom";
import AddBlog from './blogs/AddBlog';
import Blogs from './blogs/Blogs';
import {connect} from 'react-redux'
class NvBar extends Component {



  login(e)
  {
    this.props.dispatch({type:"loginclicked"})
  }
  logout(e)
  {
    this.props.dispatch({type:"logoutclicked"})
  }
    render() {
        return (
            <div>
                <BrowserRouter>
                <div>
                <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  
  <a class="navbar-brand" href="#">SocialActivity</a>

  
  <ul class="navbar-nav">
    <li class="nav-item">
      <Link to="/reg" class="nav-link" >Register</Link>
    </li>
    <li class="nav-item">
      <Link  to="/log" class="nav-link" >Login</Link>
    </li>
    {this.props.signInInfo?
    <Link class="nav-link"  onClick={this.logout.bind(this)}>signOut</Link>:
    <Link class="nav-link" onClick={this.login.bind(this)}>signIn</Link>}
   
    <li class="nav-item">
      <Link  to="/addblog" class="nav-link" >addblog</Link>
    </li>
    <li class="nav-item">
      <Link to="/showblog" class="nav-link" >showblogs</Link>
    </li>
    
    
  </ul>
</nav>



</div>

 


  
        <Switch>
        <Route path="/addblog"  component={AddBlog} />
  
  
        <Route path="/showblog"  component={Blogs} />
      </Switch>
        </BrowserRouter>

            </div>
        );
    }
}
const f1=(state)=>({uName:state.userName,signInInfo:state.loginInfo})
export default connect(f1)(NvBar);