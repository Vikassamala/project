import React, { Component } from 'react';
import { connect } from 'react-redux';
import {firebase} from '../dbconfig/firebaseconfig';

class AddBlog extends Component {
    constructor(props)
    {
        super(props);
         this.state=
         {
             blog_id:'',
             blog_title:'',
             blog_description:'',
             blog_owner:''

         }
    }
    storeBlog(e)
    {
        this.setState({[e.target.name]:e.target.value})
        
    }
    addblog(e)
    { e.preventDefault();
        const blog={
        blogid:this.state.blog_id,
        blogtitle:this.state.  blog_title,
        blogdescription:this.state.blog_description,
        blogowner:this.state.blog_owner
    }
    const fbref=firebase.database().ref('blogs')
    fbref.push(blog)

    }
    render() {
        return (
            <div>
              {this.props.signInInfo?
            <form action="/action_page.php" onSubmit={this.addblog.bind(this)}>
              <div class="form-group">
                <label for="Blogid">Blogid</label>
                <input type="text" class="form-control" id="Blogid" placeholder="Enter Blogid" name="blog_id" onChange={this.storeBlog.bind(this)}/>
              </div>
              <div class="form-group">
                <label for="Blogtitle">Blogtitle</label>
                <input type="text" class="form-control" id="Blogtitle" placeholder="Enter Blogtitle" name="blog_title" onChange={this.storeBlog.bind(this)}/>
              </div>
              <div class="form-group">
                <label for="Blogdiscription">Blogdiscription</label>
                <input type="text" class="form-control" id="Blogdiscription" placeholder="Enter Blogdiscription" name="blog_description" onChange={this.storeBlog.bind(this)}/>
              </div>
              <div class="form-group">
                <label for="BlogOwner">BlogOwner</label>
                <input type="text" class="form-control" id="BlogOwner" placeholder="Enter BlogOwner" name="blog_owner" onChange={this.storeBlog.bind(this)} />
              </div>
            
            
              <button type="submit" class="btn btn-primary">AddBlog</button>
            </form>  :
            <h2>please sign in to addblog</h2>}
            </div>
        );
    }
}
const f1=(state)=>({uName:state.userName,signInInfo:state.loginInfo})
export default connect(f1)(AddBlog);