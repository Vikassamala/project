import React, { Component } from 'react';
import {firebase} from '../dbconfig/firebaseconfig'

class Blogs extends Component {
  constructor(props)
  { super(props);
    this.state=
    {
      blog:[]
    }
  }
  componentDidMount()
  {
      const fbref=firebase.database().ref('blogs');
      fbref.on('value',(snapshot)=>
      {
           const blogRawdata=snapshot.val();
           console.log(blogRawdata);
           const blogList=[];
           for(let h in  blogRawdata )
           {
               blogList.push({h,...blogRawdata[h]});
           }
           console.log( blogList);
           this.setState({blog: blogList});
      })
  }
    render() {
        return (
            <div>
<div class="container">         
  <table class="table table-dark table-striped">
    <thead>
      <tr>
        <th>Blogid</th>
        <th>Blogtitle</th>
        <th>Blogdiscription</th>
        <th>BlogOwner</th>
      </tr>
    </thead>
    <tbody>
      {
      this.state.blog.map(x=>
      <tr>
        <td>{x.blogid}</td>
        <td>{x.blogtitle}</td>
        <td>{x.blogdescription}</td>
        <td>{x.blogowner}</td>
      </tr>)
      }
    </tbody>
  </table>
</div>   
            </div>
        );
    }
}

export default Blogs;