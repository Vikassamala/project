import firebase from 'firebase'
var firebaseConfig = {
    apiKey: "AIzaSyCqkxj6rigmNNK14kt_o7GSAUIb1pNuGR8",
    authDomain: "activity-c8b98.firebaseapp.com",
    projectId: "activity-c8b98",
    storageBucket: "activity-c8b98.appspot.com",
    messagingSenderId: "58835730051",
    appId: "1:58835730051:web:a966527a6412ec1114a5b6"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const auth=firebase.auth();
  const storage=firebase.storage();
  const provider= new firebase.auth.GoogleAuthProvider();
   export {auth,storage,provider,firebase};