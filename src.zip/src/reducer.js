import { signIn } from "./components/Authentication"

const baseState=
{
    userName:'guest',
    loginInfo:false,
    user:''

}

export  async function reducer(state=baseState,action)
{

if(action.type==="loginclicked")
{ let usr=await signIn();
    return{
        user:usr, loginInfo:true,userName:"harsha",
    };
}
else if(action.type==="logoutclicked")
{
    return{
        loginInfo:false,userName:"guest"
    }
}return state;

}